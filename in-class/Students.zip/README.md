# SOURCE

The datasets come from the National Longitudinal Survey of 1972 (NLS72). https://nces.ed.gov/surveys/nls72/ 

# Dataset Variable Explanations

## Students-Demo.csv
NLS student level data, containing variables about student demographics

* id = "unique school code of high school student attended"
* schcode = "SCHOOL CODE"
* bysex = "SEX OF STUDENT FROM BASE YEAR INSTRUMENT"
* csex = "CSEX - SEX OF RESPONDENT"
* crace = "RACE COMPOSITE"
* cbirthm = "COMPOSITE BIRTH MONTH"
* cbirthd = "COMPOSITE BIRTH DAY"
* cbirthyr = "COMPOSITE BIRTH YEAR"

## Students-Postsecondary.csv
NLS student level data, containing variables about postsecondary education transcripts

* id = "unique student identification variable"
* reqtrans = "NUMBER OF TRANSCRIPTS REQUESTED"
* numtrans = "NUMBER OF TRANSCRIPTS RECEIVED"

## Students-Transcripts.csv
NLS student-transcript level data

* id = "unique student identification variable"
* transnum = "TRANSCRIPT NUMBER"
* findisp = "FINAL DISPOSITION"
* trnsflag = "TRANSCRIPT FLAG"
* terms = "NUMBER OF TERMS ON THIS TRANSCRIPT"
* fice = "POSTSECONDARY INSTITUTION ID CODE"
* state = "state"
* cofcon = "OFFERING & CONTROL"
* instype = "INSTITUTION TYPE"
* itype = "INSTITUTION TYPE"

## Students-Transcripts-Term-Level.csv
NLS student-transcript-term level data

* id = "unique student identification variable"
* transnum = "TRANSCRIPT NUMBER"
* termnum = "TERM NUMBER"
* courses = "NUMBER OF COURSES TERM"
* termtype = "TYPE OF TERM"
* season = "SEASON OF TERM"
* sortdate = "DATE OF TERM" 
* gradcode = "GRADE SCALE TYPE"
* transfer = "TRANSFER COURSES FLAG"

